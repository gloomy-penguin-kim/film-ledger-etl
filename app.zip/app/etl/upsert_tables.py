
from typing import Any


def upsert_keywords(conn, media_id: int, media: dict[str, Any]) -> None:
    keywords = media.get("keywords") or []

    for keyword_name in keywords:
        keyword_name = keyword_name.strip()

        if not keyword_name:
            continue

        with conn.execute(
            """
            INSERT INTO keyword (keyword_name)
            VALUES (%s)
            ON CONFLICT (keyword_name)
            DO UPDATE SET keyword_name = EXCLUDED.keyword_name 
            RETURNING keyword_id;
            """,
            (keyword_name,),
        ) as cur:
            keyword_id = cur.fetchone()[0]

        conn.execute(
            """
            INSERT INTO media_keyword (media_id, keyword_id)
            VALUES (%s, %s)
            ON CONFLICT (media_id, keyword_id)
            DO NOTHING;
            """,
            (media_id, keyword_id),
        )


def upsert_genres(conn, media_id: int, media: dict[str, Any]) -> None: 
    genres = media.get("genres") or []

    for genre_name in genres:
        genre_name = genre_name.strip()

        if not genre_name:
            continue

        with conn.execute(
            """
            INSERT INTO genre (genre_name)
            VALUES (%s)
            ON CONFLICT (genre_name)
            DO UPDATE SET genre_name = EXCLUDED.genre_name
            RETURNING genre_id;
            """,
            (genre_name,),
        ) as cur:
            genre_id = cur.fetchone()[0]

        conn.execute(
            """
            INSERT INTO media_genre (media_id, genre_id)
            VALUES (%s, %s)
            ON CONFLICT (media_id, genre_id)
            DO NOTHING;
            """,
            (media_id, genre_id),
        )


def upsert_languages(conn, media_id: int, media: dict[str, Any]) -> None:
    languages = media.get("languages") or []
 
    for language_name in languages:
        language_name = language_name.strip()

        if not language_name:
            continue

        with conn.execute(
            """
            INSERT INTO language (language_name)
            VALUES (%s)
            ON CONFLICT (language_name)
            DO UPDATE SET language_name = EXCLUDED.language_name 
            RETURNING language_id;
            """,
            (language_name,),
        ) as cur:
            language_id = cur.fetchone()[0]  

        conn.execute(
            """
            INSERT INTO media_language (media_id, language_id)
            VALUES (%s, %s)
            ON CONFLICT (media_id, language_id)
            DO NOTHING;
            """,
            (media_id, language_id),
        )


def upsert_connections(conn, media_id: int, media: dict[str, Any]) -> None:
    connections = media.get("connections") or []

    for connection in connections:
        connection_name = connection.get("relationship").strip()

        if not connection_name:
            continue

        with conn.execute(
                """
                INSERT INTO connection (connection_name)
                VALUES (%s)
                ON CONFLICT (connection_name) 
                    DO UPDATE SET connection_name = EXCLUDED.connection_name 
                RETURNING connection_id;
                """,
                (connection_name,),
        ) as cur:
            connection_id = cur.fetchone()[0]

        conn.execute(
            """
            INSERT INTO media_connection (media_id, related_media_id, 
                                          related_media_year, related_media_imdb_id, 
                                          connection_id)
                SELECT %(media_id)s, 
                       m.media_id as related_media_id, 
                       %(related_media_year)s, 
                       %(related_media_imdb_id)s, 
                       %(connection_id)s
                FROM   media m
                WHERE  m.media_imdb_id = %(related_media_imdb_id)s  
            ON CONFLICT (media_id, related_media_id, connection_id)
            DO NOTHING;
            """,
            {
                "media_id": media_id,
                "related_media_imdb_id": connection.get("id"),
                "related_media_year": connection.get("year"),
                "connection_id": connection_id,
            },
        )


def upsert_similar_titles(conn, media_id: int, media: dict[str, Any]) -> None:

    for similar in (media.get("similar_titles") or []):
        similar_id = similar.get("id").strip()

        if not similar_id:
            continue

        conn.execute(
            """
            INSERT INTO media_similar_titles (media_id, 
                                              related_media_id, 
                                              related_media_imdb_id)
                SELECT %(media_id)s, 
                       m.media_id as related_media_id, 
                       %(related_media_imdb_id)s
                FROM   media m
                WHERE  m.media_imdb_id = %(related_media_imdb_id)s  
            ON CONFLICT (media_id, related_media_id) 
            DO NOTHING;
            """,
            {
                "media_id": media_id,
                "related_media_imdb_id": similar.get("id")
            },
        )



